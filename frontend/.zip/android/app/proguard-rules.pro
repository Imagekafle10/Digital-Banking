# Flutter wrapper
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# webview_flutter
-keep class com.google.android.webview.** { *; }

# Keep model/annotation classes from being stripped if reflection is ever added later
-keepattributes *Annotation*
